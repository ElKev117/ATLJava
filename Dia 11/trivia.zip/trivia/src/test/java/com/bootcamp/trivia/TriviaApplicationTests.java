package com.bootcamp.trivia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TriviaApplicationTests {

	@Test
	void contextLoads() {
	}

}
