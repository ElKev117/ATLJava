package com.Autocompletar.Autocompletar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutocompletarApplicationTests {

	@Test
	void contextLoads() {
	}

}
